export type ExamType = 'JEE' | 'MHT-CET' | 'NEET';
export type Category = 'General' | 'OBC' | 'SC' | 'ST' | 'EWS';
export type Gender = 'Male' | 'Female' | 'Other';
export type CollegeType = 'Government' | 'Private' | 'Deemed';
export type ProbabilityLevel = 'High' | 'Moderate' | 'Low';

export interface FormData {
  examType: ExamType;
  score: number;
  category: Category;
  gender: Gender;
  state: string;
  preferredBranches: string[];
}

export interface College {
  id: string;
  name: string;
  branch: string;
  location: string;
  city: string;
  state: string;
  cutoff: number;
  type: CollegeType;
  probability: ProbabilityLevel;
  historicalCutoffs?: number[];
}

export interface FilterOptions {
  branches: string[];
  cities: string[];
  types: CollegeType[];
}
