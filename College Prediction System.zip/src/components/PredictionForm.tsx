import { useState } from 'react';
import { FormData, ExamType, Category, Gender } from '@/types/college';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { indianStates, allBranches, medicalBranchesExport } from '@/lib/collegeData';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

interface PredictionFormProps {
  onSubmit: (data: FormData) => void;
  isLoading?: boolean;
}

export function PredictionForm({ onSubmit, isLoading }: PredictionFormProps) {
  const [formData, setFormData] = useState<FormData>({
    examType: 'JEE',
    score: 0,
    category: 'General',
    gender: 'Male',
    state: '',
    preferredBranches: [],
  });

  const [selectedBranch, setSelectedBranch] = useState('');

  const availableBranches = formData.examType === 'NEET' ? medicalBranchesExport : allBranches;

  const handleAddBranch = (branch: string) => {
    if (branch && !formData.preferredBranches.includes(branch)) {
      setFormData({
        ...formData,
        preferredBranches: [...formData.preferredBranches, branch],
      });
      setSelectedBranch('');
    }
  };

  const handleRemoveBranch = (branch: string) => {
    setFormData({
      ...formData,
      preferredBranches: formData.preferredBranches.filter(b => b !== branch),
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.score > 0) {
      onSubmit(formData);
    }
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onSubmit={handleSubmit}
      className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8 md:p-12 border border-border"
    >
      <motion.h1
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="font-display text-4xl md:text-5xl font-bold text-center mb-2 text-foreground"
      >
        Find Your Perfect College
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="text-center text-muted-foreground mb-8 md:mb-12"
      >
        Enter your exam details to predict your college admission chances
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {/* Exam Type */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.3 }}
          className="space-y-2"
        >
          <Label htmlFor="examType" className="text-base font-medium">
            Exam Type
          </Label>
          <Select
            value={formData.examType}
            onValueChange={(value: ExamType) =>
              setFormData({ ...formData, examType: value, preferredBranches: [] })
            }
          >
            <SelectTrigger id="examType" className="h-12">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="JEE">JEE (Joint Entrance Examination)</SelectItem>
              <SelectItem value="MHT-CET">MHT-CET (Maharashtra CET)</SelectItem>
              <SelectItem value="NEET">NEET (Medical Entrance)</SelectItem>
            </SelectContent>
          </Select>
        </motion.div>

        {/* Score */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.3 }}
          className="space-y-2"
        >
          <Label htmlFor="score" className="text-base font-medium">
            Score / Percentile
          </Label>
          <Input
            id="score"
            type="number"
            placeholder="Enter your score"
            value={formData.score || ''}
            onChange={(e) =>
              setFormData({ ...formData, score: parseFloat(e.target.value) || 0 })
            }
            className="h-12"
            min={0}
            max={720}
            required
          />
        </motion.div>

        {/* Category */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="space-y-2"
        >
          <Label htmlFor="category" className="text-base font-medium">
            Category
          </Label>
          <Select
            value={formData.category}
            onValueChange={(value: Category) =>
              setFormData({ ...formData, category: value })
            }
          >
            <SelectTrigger id="category" className="h-12">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="General">General</SelectItem>
              <SelectItem value="OBC">OBC (Other Backward Classes)</SelectItem>
              <SelectItem value="SC">SC (Scheduled Caste)</SelectItem>
              <SelectItem value="ST">ST (Scheduled Tribe)</SelectItem>
              <SelectItem value="EWS">EWS (Economically Weaker Section)</SelectItem>
            </SelectContent>
          </Select>
        </motion.div>

        {/* State */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.3 }}
          className="space-y-2"
        >
          <Label htmlFor="state" className="text-base font-medium">
            State
          </Label>
          <Select
            value={formData.state}
            onValueChange={(value) =>
              setFormData({ ...formData, state: value })
            }
          >
            <SelectTrigger id="state" className="h-12">
              <SelectValue placeholder="Select your state" />
            </SelectTrigger>
            <SelectContent>
              {indianStates.map((state) => (
                <SelectItem key={state} value={state}>
                  {state}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>

        {/* Gender */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.3 }}
          className="space-y-2 md:col-span-2"
        >
          <Label className="text-base font-medium">Gender</Label>
          <RadioGroup
            value={formData.gender}
            onValueChange={(value: Gender) =>
              setFormData({ ...formData, gender: value })
            }
            className="flex flex-wrap gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="Male" id="male" />
              <Label htmlFor="male" className="cursor-pointer font-normal">Male</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="Female" id="female" />
              <Label htmlFor="female" className="cursor-pointer font-normal">Female</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="Other" id="other" />
              <Label htmlFor="other" className="cursor-pointer font-normal">Other</Label>
            </div>
          </RadioGroup>
        </motion.div>

        {/* Preferred Branches */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45, duration: 0.3 }}
          className="space-y-2 md:col-span-2"
        >
          <Label htmlFor="branches" className="text-base font-medium">
            Preferred Branches (Optional)
          </Label>
          <div className="flex gap-2">
            <Select value={selectedBranch} onValueChange={handleAddBranch}>
              <SelectTrigger id="branches" className="h-12 flex-1">
                <SelectValue placeholder="Select branches..." />
              </SelectTrigger>
              <SelectContent>
                {availableBranches
                  .filter(branch => !formData.preferredBranches.includes(branch))
                  .map((branch) => (
                    <SelectItem key={branch} value={branch}>
                      {branch}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          
          {formData.preferredBranches.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {formData.preferredBranches.map((branch) => (
                <motion.div
                  key={branch}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium"
                >
                  {branch}
                  <button
                    type="button"
                    onClick={() => handleRemoveBranch(branch)}
                    className="hover:bg-primary/20 rounded-full p-0.5 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.3 }}
        className="mt-8 md:mt-10"
      >
        <Button
          type="submit"
          size="lg"
          className="w-full h-14 text-lg font-semibold"
          disabled={isLoading || formData.score <= 0}
        >
          {isLoading ? 'Predicting...' : 'Predict My Colleges'}
        </Button>
      </motion.div>
    </motion.form>
  );
}
