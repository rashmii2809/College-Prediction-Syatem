import { FilterOptions, CollegeType } from '@/types/college';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { X, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface FilterPanelProps {
  filters: FilterOptions;
  selectedBranches: string[];
  selectedCities: string[];
  selectedTypes: CollegeType[];
  onBranchToggle: (branch: string) => void;
  onCityToggle: (city: string) => void;
  onTypeToggle: (type: CollegeType) => void;
  onClearFilters: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export function FilterPanel({
  filters,
  selectedBranches,
  selectedCities,
  selectedTypes,
  onBranchToggle,
  onCityToggle,
  onTypeToggle,
  onClearFilters,
  isOpen = true,
  onClose,
}: FilterPanelProps) {
  const activeFilterCount = 
    selectedBranches.length + selectedCities.length + selectedTypes.length;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Mobile Overlay */}
          {onClose && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            />
          )}

          {/* Filter Panel */}
          <motion.div
            initial={{ x: -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed lg:sticky top-0 left-0 h-screen lg:h-auto w-80 bg-white border-r lg:border border-border z-50 lg:rounded-xl overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-border flex items-center justify-between bg-muted/30">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-primary" />
                <h3 className="font-display text-xl font-bold">Filters</h3>
                {activeFilterCount > 0 && (
                  <Badge variant="default" className="ml-2">
                    {activeFilterCount}
                  </Badge>
                )}
              </div>
              {onClose && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="lg:hidden"
                >
                  <X className="w-5 h-5" />
                </Button>
              )}
            </div>

            {/* Filter Content */}
            <ScrollArea className="flex-1 p-6">
              <div className="space-y-8">
                {/* Branch Filter */}
                {filters.branches.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-sm mb-3 text-foreground">Branch</h4>
                    <div className="space-y-3">
                      {filters.branches.map((branch) => (
                        <div key={branch} className="flex items-center space-x-2">
                          <Checkbox
                            id={`branch-${branch}`}
                            checked={selectedBranches.includes(branch)}
                            onCheckedChange={() => onBranchToggle(branch)}
                          />
                          <Label
                            htmlFor={`branch-${branch}`}
                            className="text-sm font-normal cursor-pointer flex-1"
                          >
                            {branch}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* City Filter */}
                {filters.cities.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-sm mb-3 text-foreground">City</h4>
                    <div className="space-y-3">
                      {filters.cities.slice(0, 10).map((city) => (
                        <div key={city} className="flex items-center space-x-2">
                          <Checkbox
                            id={`city-${city}`}
                            checked={selectedCities.includes(city)}
                            onCheckedChange={() => onCityToggle(city)}
                          />
                          <Label
                            htmlFor={`city-${city}`}
                            className="text-sm font-normal cursor-pointer flex-1"
                          >
                            {city}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* College Type Filter */}
                <div>
                  <h4 className="font-semibold text-sm mb-3 text-foreground">College Type</h4>
                  <div className="space-y-3">
                    {filters.types.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox
                          id={`type-${type}`}
                          checked={selectedTypes.includes(type)}
                          onCheckedChange={() => onTypeToggle(type)}
                        />
                        <Label
                          htmlFor={`type-${type}`}
                          className="text-sm font-normal cursor-pointer flex-1"
                        >
                          {type}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>

            {/* Clear Filters Button */}
            {activeFilterCount > 0 && (
              <div className="p-6 border-t border-border bg-muted/30">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={onClearFilters}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
