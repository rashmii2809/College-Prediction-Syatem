import { College, ProbabilityLevel } from '@/types/college';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Heart, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface CollegeCardProps {
  college: College;
  index: number;
  isSaved?: boolean;
  onToggleSave?: (collegeId: string) => void;
}

const probabilityConfig: Record<ProbabilityLevel, { color: string; bgColor: string; text: string }> = {
  High: { 
    color: 'text-teal-700', 
    bgColor: 'bg-teal-50 border-teal-200', 
    text: 'High Chance' 
  },
  Moderate: { 
    color: 'text-amber-700', 
    bgColor: 'bg-amber-50 border-amber-200', 
    text: 'Moderate' 
  },
  Low: { 
    color: 'text-red-500', 
    bgColor: 'bg-red-50 border-red-200', 
    text: 'Low Chance' 
  },
};

export function CollegeCard({ college, index, isSaved, onToggleSave }: CollegeCardProps) {
  const config = probabilityConfig[college.probability];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ 
        duration: 0.3, 
        delay: index * 0.05,
        ease: [0.16, 1, 0.3, 1]
      }}
      whileHover={{ 
        y: -4,
        transition: { duration: 0.2 }
      }}
      className="h-full"
    >
      <Card className="h-full p-6 hover:shadow-xl transition-shadow duration-200 border border-border relative overflow-hidden group">
        {/* Probability Badge - Top Right */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="absolute top-4 right-4"
        >
          <Badge 
            variant="outline" 
            className={cn(
              'px-3 py-1.5 font-medium border',
              config.bgColor,
              config.color
            )}
          >
            <motion.span
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              {config.text}
            </motion.span>
          </Badge>
        </motion.div>

        {/* Bookmark Button - Top Left */}
        {onToggleSave && (
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onToggleSave(college.id)}
            className="absolute top-4 left-4 p-2 rounded-full hover:bg-muted transition-colors"
          >
            <Heart 
              className={cn(
                'w-5 h-5 transition-colors',
                isSaved 
                  ? 'fill-red-500 text-red-500' 
                  : 'text-muted-foreground hover:text-red-500'
              )}
            />
          </motion.button>
        )}

        {/* Content */}
        <div className="mt-8">
          <h3 className="font-display text-2xl font-bold text-foreground mb-2 pr-8">
            {college.name}
          </h3>
          
          <div className="flex items-center gap-2 mb-3">
            <Badge variant="secondary" className="text-sm font-medium">
              {college.branch}
            </Badge>
            <Badge variant="outline" className="text-sm">
              {college.type}
            </Badge>
          </div>

          <div className="flex items-center gap-2 text-muted-foreground mb-4">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{college.location}</span>
          </div>

          <div className="pt-4 border-t border-border">
            <div className="flex items-baseline justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Cutoff Score</p>
                <p className="font-mono text-3xl font-semibold text-primary">
                  {college.cutoff}
                </p>
              </div>

              {college.historicalCutoffs && college.historicalCutoffs.length > 0 && (
                <motion.div 
                  whileHover={{ scale: 1.05 }}
                  className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                  title="View historical trends"
                >
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-xs font-medium">Trends</span>
                </motion.div>
              )}
            </div>

            {/* Mini Sparkline - Optional Historical Data Visualization */}
            {college.historicalCutoffs && college.historicalCutoffs.length > 0 && (
              <div className="mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="flex items-end gap-1 h-8">
                  {college.historicalCutoffs.map((cutoff, idx) => {
                    const maxCutoff = Math.max(...college.historicalCutoffs!);
                    const height = (cutoff / maxCutoff) * 100;
                    return (
                      <motion.div
                        key={idx}
                        initial={{ height: 0 }}
                        animate={{ height: `${height}%` }}
                        transition={{ delay: idx * 0.05, duration: 0.3 }}
                        className="flex-1 bg-primary/20 rounded-t"
                        title={`Year ${idx + 1}: ${cutoff}`}
                      />
                    );
                  })}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Historical cutoffs (last 5 years)</p>
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
