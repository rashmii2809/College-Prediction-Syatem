import { useState, useMemo } from 'react';
import { College, CollegeType } from '@/types/college';
import { CollegeCard } from './CollegeCard';
import { FilterPanel } from './FilterPanel';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, SlidersHorizontal, Edit } from 'lucide-react';

interface ResultsSectionProps {
  colleges: College[];
  onEditForm: () => void;
  savedColleges: string[];
  onToggleSave: (collegeId: string) => void;
}

type SortOption = 'best-match' | 'cutoff-low' | 'cutoff-high' | 'location';

export function ResultsSection({ colleges, onEditForm, savedColleges, onToggleSave }: ResultsSectionProps) {
  const [selectedBranches, setSelectedBranches] = useState<string[]>([]);
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<CollegeType[]>([]);
  const [sortBy, setSortBy] = useState<SortOption>('best-match');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Extract unique filters from colleges
  const filters = useMemo(() => {
    const branches = Array.from(new Set(colleges.map(c => c.branch))).sort();
    const cities = Array.from(new Set(colleges.map(c => c.city))).sort();
    const types: CollegeType[] = Array.from(new Set(colleges.map(c => c.type)));
    
    return { branches, cities, types };
  }, [colleges]);

  // Filter colleges
  const filteredColleges = useMemo(() => {
    return colleges.filter(college => {
      if (selectedBranches.length > 0 && !selectedBranches.includes(college.branch)) {
        return false;
      }
      if (selectedCities.length > 0 && !selectedCities.includes(college.city)) {
        return false;
      }
      if (selectedTypes.length > 0 && !selectedTypes.includes(college.type)) {
        return false;
      }
      return true;
    });
  }, [colleges, selectedBranches, selectedCities, selectedTypes]);

  // Sort colleges
  const sortedColleges = useMemo(() => {
    const sorted = [...filteredColleges];
    
    switch (sortBy) {
      case 'cutoff-low':
        return sorted.sort((a, b) => a.cutoff - b.cutoff);
      case 'cutoff-high':
        return sorted.sort((a, b) => b.cutoff - a.cutoff);
      case 'location':
        return sorted.sort((a, b) => a.city.localeCompare(b.city));
      case 'best-match':
      default:
        // Already sorted by probability and cutoff in data generator
        return sorted;
    }
  }, [filteredColleges, sortBy]);

  const handleBranchToggle = (branch: string) => {
    setSelectedBranches(prev =>
      prev.includes(branch) ? prev.filter(b => b !== branch) : [...prev, branch]
    );
  };

  const handleCityToggle = (city: string) => {
    setSelectedCities(prev =>
      prev.includes(city) ? prev.filter(c => c !== city) : [...prev, city]
    );
  };

  const handleTypeToggle = (type: CollegeType) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const handleClearFilters = () => {
    setSelectedBranches([]);
    setSelectedCities([]);
    setSelectedTypes([]);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen py-8 px-4 md:px-6 lg:px-8"
    >
      <div className="max-w-[1400px] mx-auto">
        {/* Sticky Header Bar */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border py-4 mb-8"
        >
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={onEditForm}
                className="flex items-center gap-2"
              >
                <Edit className="w-4 h-4" />
                Edit Form
              </Button>
              
              <div className="hidden md:block text-sm text-muted-foreground">
                Showing <span className="font-semibold text-foreground">{sortedColleges.length}</span> of{' '}
                <span className="font-semibold text-foreground">{colleges.length}</span> colleges
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Sort Dropdown */}
              <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                <SelectTrigger className="w-[180px] h-9">
                  <SlidersHorizontal className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="best-match">Best Match</SelectItem>
                  <SelectItem value="cutoff-low">Cutoff (Low to High)</SelectItem>
                  <SelectItem value="cutoff-high">Cutoff (High to Low)</SelectItem>
                  <SelectItem value="location">Location</SelectItem>
                </SelectContent>
              </Select>

              {/* Mobile Filter Toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="lg:hidden flex items-center gap-2"
              >
                <Filter className="w-4 h-4" />
                Filters
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="flex gap-8">
          {/* Desktop Filter Panel */}
          <aside className="hidden lg:block w-80 flex-shrink-0">
            <div className="sticky top-32">
              <FilterPanel
                filters={filters}
                selectedBranches={selectedBranches}
                selectedCities={selectedCities}
                selectedTypes={selectedTypes}
                onBranchToggle={handleBranchToggle}
                onCityToggle={handleCityToggle}
                onTypeToggle={handleTypeToggle}
                onClearFilters={handleClearFilters}
              />
            </div>
          </aside>

          {/* Mobile Filter Panel */}
          <FilterPanel
            filters={filters}
            selectedBranches={selectedBranches}
            selectedCities={selectedCities}
            selectedTypes={selectedTypes}
            onBranchToggle={handleBranchToggle}
            onCityToggle={handleCityToggle}
            onTypeToggle={handleTypeToggle}
            onClearFilters={handleClearFilters}
            isOpen={isFilterOpen}
            onClose={() => setIsFilterOpen(false)}
          />

          {/* Results Grid */}
          <div className="flex-1">
            {sortedColleges.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-16"
              >
                <div className="max-w-md mx-auto">
                  <div className="w-24 h-24 mx-auto mb-6 bg-muted rounded-full flex items-center justify-center">
                    <Filter className="w-12 h-12 text-muted-foreground" />
                  </div>
                  <h3 className="font-display text-2xl font-bold mb-2">No colleges found</h3>
                  <p className="text-muted-foreground mb-6">
                    Try adjusting your filters to see more results
                  </p>
                  <Button variant="outline" onClick={handleClearFilters}>
                    Clear All Filters
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                layout
                className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
              >
                <AnimatePresence mode="popLayout">
                  {sortedColleges.map((college, index) => (
                    <motion.div
                      key={college.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <CollegeCard
                        college={college}
                        index={index}
                        isSaved={savedColleges.includes(college.id)}
                        onToggleSave={onToggleSave}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
