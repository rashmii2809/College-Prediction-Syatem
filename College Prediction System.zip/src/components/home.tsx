import { useState } from 'react';
import { FormData, College } from '@/types/college';
import { PredictionForm } from './PredictionForm';
import { ResultsSection } from './ResultsSection';
import { generateCollegeResults } from '@/lib/collegeData';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';

function Home() {
  const [colleges, setColleges] = useState<College[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [savedColleges, setSavedColleges] = useState<string[]>([]);

  const handleFormSubmit = async (formData: FormData) => {
    setIsLoading(true);
    
    // Simulate loading for better UX
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const results = generateCollegeResults(formData);
    setColleges(results);
    setIsLoading(false);
    setShowResults(true);
  };

  const handleEditForm = () => {
    setShowResults(false);
  };

  const handleToggleSave = (collegeId: string) => {
    setSavedColleges(prev =>
      prev.includes(collegeId)
        ? prev.filter(id => id !== collegeId)
        : [...prev, collegeId]
    );
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Subtle background texture/pattern */}
      <div 
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <AnimatePresence mode="wait">
        {!showResults ? (
          <motion.div
            key="form"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12"
          >
            {/* Logo/Branding */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mb-8 flex items-center gap-2"
            >
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <h1 className="font-display text-3xl font-bold text-primary">CollegePredict</h1>
            </motion.div>

            <PredictionForm onSubmit={handleFormSubmit} isLoading={isLoading} />

            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-8 text-center"
              >
                <div className="inline-flex items-center gap-2 px-6 py-3 bg-white rounded-full shadow-lg border border-border">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Sparkles className="w-5 h-5 text-primary" />
                  </motion.div>
                  <span className="text-sm font-medium text-foreground">
                    Analyzing your eligibility...
                  </span>
                </div>
              </motion.div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="results"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="relative z-10"
          >
            <ResultsSection
              colleges={colleges}
              onEditForm={handleEditForm}
              savedColleges={savedColleges}
              onToggleSave={handleToggleSave}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default Home;
