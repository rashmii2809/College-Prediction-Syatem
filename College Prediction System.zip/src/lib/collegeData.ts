import { College, CollegeType, ExamType, FormData, ProbabilityLevel } from '@/types/college';

const branches = [
  'Computer Science',
  'Electronics',
  'Mechanical',
  'Civil',
  'Electrical',
  'Information Technology',
  'Chemical',
  'Biotechnology',
  'Aerospace',
  'Automobile',
];

const cities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad',
  'Pune', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Lucknow',
  'Kanpur', 'Nagpur', 'Indore', 'Bhopal', 'Visakhapatnam'
];

const collegeNames = {
  JEE: [
    'IIT Delhi',
    'IIT Bombay',
    'IIT Madras',
    'IIT Kanpur',
    'IIT Kharagpur',
    'NIT Trichy',
    'NIT Warangal',
    'NIT Surathkal',
    'IIIT Hyderabad',
    'BITS Pilani',
    'Delhi Technological University',
    'VIT Vellore',
    'Manipal Institute of Technology',
    'Thapar University',
  ],
  'MHT-CET': [
    'VJTI Mumbai',
    'COEP Pune',
    'PICT Pune',
    'SPIT Mumbai',
    'DJ Sanghvi Mumbai',
    'KJ Somaiya Mumbai',
    'Sardar Patel COE Mumbai',
    'Walchand College of Engineering',
    'Government College of Engineering Pune',
    'MIT Pune',
  ],
  NEET: [
    'AIIMS Delhi',
    'AIIMS Mumbai',
    'JIPMER Puducherry',
    'CMC Vellore',
    'Armed Forces Medical College',
    'Maulana Azad Medical College',
    'Grant Medical College Mumbai',
    'KEM Hospital Mumbai',
    'Madras Medical College',
    'King George Medical University',
  ],
};

const medicalBranches = [
  'MBBS',
  'BDS',
  'BAMS',
  'BHMS',
  'Nursing',
  'Pharmacy',
];

function calculateProbability(userScore: number, cutoff: number): ProbabilityLevel {
  const difference = userScore - cutoff;
  const percentDiff = (difference / cutoff) * 100;
  
  if (percentDiff >= 10) return 'High';
  if (percentDiff >= 0) return 'Moderate';
  return 'Low';
}

function generateHistoricalCutoffs(baseCutoff: number): number[] {
  return Array.from({ length: 5 }, (_, i) => {
    const variance = Math.random() * 20 - 10; // -10 to +10
    return Math.round(baseCutoff + variance);
  });
}

export function generateCollegeResults(formData: FormData): College[] {
  const { examType, score, category, state } = formData;
  const colleges: College[] = [];
  
  const availableColleges = collegeNames[examType];
  const availableBranches = examType === 'NEET' ? medicalBranches : branches;
  
  // Filter branches based on user preference
  const branchesToShow = formData.preferredBranches.length > 0 
    ? formData.preferredBranches 
    : availableBranches;
  
  availableColleges.forEach((collegeName, collegeIndex) => {
    branchesToShow.forEach((branch, branchIndex) => {
      // Base cutoff calculation
      let baseCutoff = 600 - (collegeIndex * 30) - (branchIndex * 10);
      
      // Adjust based on category
      const categoryAdjustment = {
        'General': 0,
        'OBC': -50,
        'SC': -100,
        'ST': -120,
        'EWS': -40,
      };
      
      baseCutoff += categoryAdjustment[category];
      
      // Random variance
      baseCutoff += Math.random() * 20 - 10;
      baseCutoff = Math.max(100, Math.round(baseCutoff));
      
      const probability = calculateProbability(score, baseCutoff);
      
      // Include colleges with moderate and high probability, plus some low ones
      if (probability === 'High' || probability === 'Moderate' || Math.random() > 0.5) {
        const city = cities[Math.floor(Math.random() * cities.length)];
        const type: CollegeType = collegeIndex < 6 ? 'Government' : 
                                   Math.random() > 0.5 ? 'Private' : 'Deemed';
        
        colleges.push({
          id: `${collegeIndex}-${branchIndex}`,
          name: collegeName,
          branch,
          location: `${city}, ${state || 'India'}`,
          city,
          state: state || 'India',
          cutoff: baseCutoff,
          type,
          probability,
          historicalCutoffs: generateHistoricalCutoffs(baseCutoff),
        });
      }
    });
  });
  
  // Sort by probability (High first) and then by cutoff
  return colleges.sort((a, b) => {
    const probabilityOrder = { High: 0, Moderate: 1, Low: 2 };
    const probDiff = probabilityOrder[a.probability] - probabilityOrder[b.probability];
    if (probDiff !== 0) return probDiff;
    return a.cutoff - b.cutoff;
  });
}

export const indianStates = [
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Manipur',
  'Meghalaya',
  'Mizoram',
  'Nagaland',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Sikkim',
  'Tamil Nadu',
  'Telangana',
  'Tripura',
  'Uttar Pradesh',
  'Uttarakhand',
  'West Bengal',
];

export const allBranches = branches;
export const medicalBranchesExport = medicalBranches;
